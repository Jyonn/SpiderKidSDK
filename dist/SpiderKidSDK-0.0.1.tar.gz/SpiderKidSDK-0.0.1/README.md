# SpiderKidSDK

SpiderKid is a versatile platform deployable either in the cloud or locally. 
It furnishes a comprehensive suite of JavaScript dependencies tailored for web spiders, with a particular focus on cryptographic functionalities that pose challenges when translated or replicated in alternative programming languages.

Built upon the SpiderKid API, SpiderKidSDK offers a streamlined approach to leverage the capabilities of the SpiderKid platform.
